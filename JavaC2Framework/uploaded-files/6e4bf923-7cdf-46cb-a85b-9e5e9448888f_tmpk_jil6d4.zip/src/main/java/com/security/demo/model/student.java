package com.security.demo.model;

import jakarta.persistence.Entity;


@Entity
public class student {
}
